package com.j3ltd.server.exceptions;

public class PersonEmailException extends Exception {
	public PersonEmailException(String message) {
		super(message);
	}
}
