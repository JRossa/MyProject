package com.j3ltd.common;

public enum MaritalStatus {
	Single, Married, Undisclosed
}
