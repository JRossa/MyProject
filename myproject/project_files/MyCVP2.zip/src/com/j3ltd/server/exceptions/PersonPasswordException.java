package com.j3ltd.server.exceptions;

public class PersonPasswordException extends Exception {
	public PersonPasswordException(String message) {
		super(message);
	}
}
