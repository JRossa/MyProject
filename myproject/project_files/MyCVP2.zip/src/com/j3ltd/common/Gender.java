package com.j3ltd.common;

public enum Gender {
	Male, Female, Undisclosed
}
